<img src="https://user-images.githubusercontent.com/77678316/208247098-77bede26-e428-48aa-9732-509c95605e19.png" width="210" height="245" /> <img src="https://user-images.githubusercontent.com/77678316/208266454-1daf4c87-fc41-46a8-95e5-31d9302290d0.png" height="245" />

# ThePirateBay Plugin for Movian <p> <img align="center" src="https://img.shields.io/badge/Version-0.2.7-bd792a?style=style=flat"> <img align="center" src="https://img.shields.io/badge/Status-Working-bd792a?style=style=flat"> </p>

> *ThePirateBay plugin for Movian/Showtime. Working in 2022-23*

## **Instalation**
**★ PlayStation 3:**

**Put the zip file inside this directory:** `dev_hdd0\game\HTSS00003\USRDIR\settings\installedplugins`

**MultiMan:** `dev_hdd0\game\BLES80608\USRDIR\sys\st4_settings\installedplugins`


> **★ Android:** `Unknown`

> **★ Linux:** `Unknown`

## Platforms Tested:
<p> <img align="center" src="https://img.shields.io/badge/PS3%20CECH2504B-4.84 DEX, 4.88 CEX, 4.89 CEX-brightgreen?style=style=flat"> </p>

## Features
- Viewning recent uploads
- Browsing content
- Listening to music
- Watching movies/shows

## To do
- Add more categories
- Add a search bar
